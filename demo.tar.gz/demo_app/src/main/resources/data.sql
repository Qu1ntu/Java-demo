INSERT INTO todo (Id,description) VALUES (1001L, 'walk the dog');
INSERT INTO todo (Id,description) VALUES (1002L,'buy food');
INSERT INTO todo (Id,description) VALUES (1003L,'do workout');
INSERT INTO todo (Id,description) VALUES (1004L,'go to job');